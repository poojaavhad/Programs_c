/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
struct student
{
    int roll;
    struct student *prev;
    struct student *next;
}
struct student* dll_last(struct student *);
display(struct student *);
struct student *Add_first(struct student *)

int main()
{
    struct student *head=NULL;
    int op;
    while(1)
    {
        printf("enter the op:\n");
        scanf("%d",&op);
        switch(op)
        {
            case 1:head=dll_last(head);
            break;
            case 2:display(head);
            break;
            case 3:exit(0);
            break;
            case 4:head=struct student(head);
            break;
            
        }
    }

    return 0;
}
struct student *Add_first(struct student *ptr)
{
	struct student *newnode=NULL;
	/***** node creation ****/
	newnode=calloc(1,sizeof(struct student ));
	if(newnode==NULL)
	{
		printf("Node not created\n");
	}
	else
	{
		// initialise the node
		printf("enter the empid\n");
		scanf("%d",&newnode->roll);
		//printf("enter the name\n");
		//scanf("%s",newnode->name);
		/*** add at head **/
		newnode->next=ptr;
		if(ptr)
			ptr->prev=newnode;
		ptr=newnode;
	
	
	}
	return ptr;
}
