/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
   main()
   {
   int n,i=sizeof(int)*8-1;
   int count=0;
   printf("enter number...\n");
   scanf("%d",&n);
  while(i>=0)
  {
    if(n>>i & 1)
       count++;//no of bits set
    i--;
  }
  printf("%d",32-count);
   }
