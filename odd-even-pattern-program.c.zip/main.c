/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,j,k;
    for(i=1;i<=5;i++)
    {
        if(i%2==0)
        k=2;
        else
        k=1;
        for(j=1;j<=i;j++){
        printf("%d",k);
        k=k+2;
        }
        printf("\n");
        //k=k+2;
        
    }
    return 0;
}
