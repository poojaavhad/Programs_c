/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
int main()
{
    unsigned int i=0x1234,temp,sum=0,r;
    printf("i=0x%x",i);
    
    while(i)
    {
        r=i%16;
        sum=sum*16+r;
        i=i/16;
    }
    printf("\nReversed Hex value is j=0x%x",sum);

    return 0;
}