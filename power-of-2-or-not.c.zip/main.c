/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
   #include<stdio.h>
   main()
   {
  char ch;
   printf("enter the character ch=");
   scanf("%c",&ch);
   if(ch>='a'&&ch<='z')
   printf("lowercase");
   else if(ch>='A'&&ch<='Z')
   printf("uppercase");
   else if(ch>=0&&ch<=9)
   printf("numeric char");
   else
   printf("special symbol");
   
   }
