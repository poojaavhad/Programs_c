/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int my_atoi(char *);
int main(int argc,char *argv[])
{
   int res;
   if(argc>=2)
   printf("valid input\n");
   else
   printf("less no of input\n");
   res=my_atoi(argv[1]);
    return 0;
}
int my_atoi(char *ptr)
{
    int i,n=0;
    printf("%s",ptr);
    if(ptr[0]=='-')
    i=1;
    else
    i=0;
    for(;ptr[i];i++)
    {
        
    if(ptr[i]>='0' && ptr[i]<='9')
    n=n*10+(ptr[i]-48);
    }
   // printf("\n%d\n",n);
    if(ptr[0]=='-')
    n=-n;
    else
    n=n;
  return n;
}
