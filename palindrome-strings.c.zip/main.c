/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>

int main()
{
    char a[20],b[20];
    int i,len,j,temp,ret;
    printf("enter the string\n");
    scanf("%s",a);
    printf("before the rev\n");
    printf("%s\n",a);
    len=strlen(a);
    for(i=0,j=len-1;i<j;i++,j--)
    {
        temp=a[i];
        a[i]=a[j];
        a[j]=temp;
    }
    strcpy(b,a);
    //printf("\n%s",b);
    printf("after the rev");
    printf("\n%s",b);
    ret=strcmp(b,a);
    if(ret==0)
    printf("strings are palindrome");
    else
    printf("strings not palindrome");
    
    

    return 0;
}
