/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n,i,j,sum=0;
    for(i=5;i<=555;i++)
    {
        sum=0;
        for(j=1;j<i;j++)
        {
        if(i%j==0)
        {
        //printf("%d",j);  
        sum=sum+j;
        }
        }
        if(sum==i)
        printf("%d",i);
        
    }
        
    
    return 0;
}

