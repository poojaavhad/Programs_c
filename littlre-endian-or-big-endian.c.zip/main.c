/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int x=1;
    int *p=&x;
    printf("%u\n",p);
    printf("%d\n",*p);
    if(*p==1)
    printf("little endian");
    else
    printf("big endian");

    return 0;
}
