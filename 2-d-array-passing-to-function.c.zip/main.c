/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
void array(int (*)[2],int,int);
int main()
{
    
  
   int a[2][2],r,c,i,j;
   r=sizeof(a)/sizeof(a[0]);
   c=sizeof(a[0])/sizeof(a[0][0]);
   printf("enter the element:");
   for(i=0;i<r;i++)
   {
       for(j=0;j<c;j++)
       scanf("%d",&a[i][j]);
   }
   
   //r=sizeof(a)/sizeof(a[0]);
   //c=sizeof(a[0])/sizeof(a[0][0]);
   array(a,r,c);
return 0;   
}
void array(int (*p)[2],int r,int c)
{
int i,j;
for(i=0;i<r;i++)
{
    for(j=0;j<c;j++)
    printf("%d",p[i][j]);
    printf("\n");
}
}

