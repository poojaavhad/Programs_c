/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int n,r,i=1;
printf("enter the number");
scanf("%d",&n);
L1:r=n*i;
printf("%d*%d=%d\n",n,i,r);
i++;
if(i<=10)
goto L1;

    return 0;
}
