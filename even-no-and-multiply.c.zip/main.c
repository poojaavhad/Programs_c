/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  unsigned int n =12345678;
  int even,mul=1;
  while(n)
  {
    even=n%10;
    if(n%2==0)
    mul=mul*even;
    //printf("%d\n",even);
    n=n/10;
  }
  printf("%d",mul);
    return 0;
}
