/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    double x=7.5;
    int i,j;
    int *ip=&x;
    printf("%u\n",&ip);
    printf("%d\n",*ip);
    ip=ip+1;
    for(i=0;i<=1;i++)
    {
    for(j=31;j>=0;j--)
    
    printf("%d",(*ip>>j)&1);
    ip=ip-1;
    
    }
    return 0;
}
