/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char a[9][10];
    int i,temp=0;
    char *p[2];
    char **dp=p;
    
    printf("enter the element in a array=");
    for(i=0;i<9;i++)
    scanf("%s",a[i]);
    for(i=0;i<9;i++)
    printf("%s ",a[i]);
    temp=a[5];
    a[5]=a[8];
    a[8]=temp;
    for(i=0;i<9;i++)
    printf("%s ",a[i]);
    return 0;
}
