/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a[5],i,j,temp,n;
    n=sizeof(a)/sizeof(a[0]);
    printf("enter the element\n");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    for(i=0,j=n-1;i<j;i++,j--)
    {
        temp=a[i];
        a[i]=a[j];
        a[j]=temp;
    }    
        
    
    for(i=0;i<n;i++)
    printf("%d ",a[i]);
    
    

    return 0;
}
