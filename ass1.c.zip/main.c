/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
   int a=0xff,i;
   for(i=7;i>=0;i--)
   printf("%d",a>>i&1);
    
for(i=7;i>=0;i--)
   printf("%d",a|(1<<3));
    
    
    

    return 0;
}

