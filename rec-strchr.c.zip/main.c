/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
char * strchr1(char*,char);
int main()
{
char a[10]="love";
char ch='v';
char *p;
printf("%u\n",a);
p=strchr1(a,ch);
printf("%u",p);


    return 0;
}
char * strchr1(char*p,char ch)
{
    static int i; 
    if(p[i]==ch)
    return p+i;
    else
    {
    i++;
    strchr1(p++,ch);
    }
}
