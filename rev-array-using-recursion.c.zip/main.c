/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int reverse(int *);
int main()
{
       int  a[5]={1,2,3,4,5};
       reverse(a);

    return 0;
}
int reverse(int *p)
{
   static int i ;
   //printf("%d",i);
   if(i<=4){
  i++;
 reverse(p+1);
   }
 else
 return 0;
 

 printf("%d\n",*p);
//return *p;
 
}
