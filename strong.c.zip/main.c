/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int n,temp,temp1,sum=0,i;
printf("enter the number n=");
scanf("%d",&n);
temp1=n;
while(n)
{
    temp=n%10;
    n=n/10;
    //printf("%d",temp);
for(i=(temp-1);i>0;i--)
temp=temp*i;

sum=sum+temp;
}
//printf("sum=%d",sum);
if(sum==temp1)
printf("strong no");
else 
printf("not strong no");

    


return 0;
}
