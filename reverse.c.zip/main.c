/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,temp,rev=0;
    printf("enter the number a=");
    scanf("%d",&a);
    while(a>0)
    {
        temp=a%10;
        rev=rev*10+temp;
        a=a/10;
    }
    printf("reverse number is=%d",rev);
    
    

    return 0;
}
