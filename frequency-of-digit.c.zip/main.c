/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/


#include <stdio.h>
#include<string.h>

main ()
{
  char a[20], b[10] = "0123456789";
  static int i, c, c1, c2, c3, c4, c5, c6, c7, c8, c9;
  printf ("Enter Your String: \n");
  scanf ("%s", a);
  for (i = 0; a[i]; i++)
    {
      if (a[i] == b[0])
	c++;
      else if (a[i] == b[1])
	c1++;
      else if (a[i] == b[2])
	c2++;
      else if (a[i] == b[3])
	c3++;
      else if (a[i] == b[4])
	c4++;
      else if (a[i] == b[5])
	c5++;
      else if (a[i] == b[6])
	c6++;
      else if (a[i] == b[7])
	c7++;
      else if (a[i] == b[8])
	c8++;
      else if (a[i] == b[9])
	c9++;
    }
  printf ("%d\n", c);
  printf ("%d\n", c1);
  printf ("%d\n", c2);
  printf ("%d\n", c3);
  printf ("%d\n", c4);
  printf ("%d\n", c5);
  printf ("%d\n", c6);
  printf ("%d\n", c7);
  printf ("%d\n", c8);
  printf ("%d\n", c9);



  return 0;
}
