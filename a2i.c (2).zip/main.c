/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int my_atoi(char *);
int main(int argc,char *argv[])
{
   int res;
   if(argc>=2)
   printf("valid input\n");
   else
   printf("less no of input\n");
   res=atoi(argv[1]);
    return 0;
}
int my_atoi(char *ptr)
{
    int i;
    for(i=0;ptr[i];i++)
    printf("%d",ptr[i]);
    return 0;
}
