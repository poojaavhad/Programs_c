/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
   main()
   {
   int n,i,j,t1,t2;
   printf("enter number...\n");
   scanf("%d",&n);
   printf("before reverse...\n");
   for(i=31;i>=0;i--)
  printf("%d",n>>i & 1);
  //logic for reverse the bits
  for(i=31,j=0;i>j;i--,j++)
  {
     t1=n>>i & 1; //bits status
     t2=n>>j & 1;  //bits stat
     if(t1!=t2)  //bits are equual or not
     {
       n=n^(1<<i); //bit complimenet 
       n=n^(1<<j); //bit compliment
     }
  }
  printf("\nafter reverse the bits...\n");
  for(i=31;i>=0;i--)
  printf("%d",n>>i & 1);
  }
