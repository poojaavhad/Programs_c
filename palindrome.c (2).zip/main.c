/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>

int main()
{
    char a[10],b[10];
    int i,j,temp,len;
    printf("enter the string\n");
    scanf("%s",a);
    len=strlen(a);
    strcpy(b,a);
    //printf("%s",b);
    for(i=0,j=len-1;i<j;i++,j--)
    {
        temp=a[i];
        a[i]=a[j];
        a[j]=temp;
        
    }
    //printf("%s",a);
    if((strcmp(a,b)==0))
    printf("palindrome string\n");
    else
    printf("not palindrome string\n");

    return 0;
}
