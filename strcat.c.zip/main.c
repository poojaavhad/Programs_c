/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
char * strcat(char *,const char*);

int main()
{
   char d[20],s[10];
   char *p;
   int i;
   printf("enter the souce string=");
   scanf("%s",s);
   printf("enter the destination string=");
   scanf("%s",d);
   p=strcat(d,s);
   printf("%s",p);
    return 0;
}
char * strcat(char *d,const char *s)
{
    int i,l;
    for(i=0;d[i];i++);
    printf("%d\n",i);
    for(l=0;s[l];l++)
    {
        d[i]=s[l];
        i++;
    }
    d[i]='\0';
    return d;
    
}
