/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[5],j;
    printf("enter the element in array=\n");
    for(int i=0;i<5;i++)
    
    scanf("%d",&a[i]);
    int *p=a;
    for(int i=0;i<4;i++)
    {
        for( j=0;j<4-i-1;j++);
        {
            if(p[j]>p[j+1])
            {
                int temp=p[j];
                p[j]=p[j+1];
                p[j+1]=temp;
                
            }
        }
        
    }
    for(int i=0;i<5;i++)
    
    printf("%d",p[i]);

    return 0;
}
