/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>

int main()
{
    int n,sum=0,temp,c;
    float d,r;
    printf("enter the number n=:");
    scanf("%d",&n);
    printf("enter the number d=:");
    scanf("%f",&d);
    temp=n;
    while(n>0)
    {
        r=n%10;
        c=pow(r,d);
        sum=sum+c;
        n=n/10;
    }
    printf("%d",sum);
    if(sum==temp)
    printf("arm");
    else
    printf("not arm");
    

    return 0;
}
