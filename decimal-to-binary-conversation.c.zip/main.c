/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int i,n;
   printf("enter the number n=");
   scanf("%d",&n);
   if(n>=0 && n<=7)
   i=2;
   else if(n>=8 && n<=15)
   i=3;
   else if(n>=16 && n<=31)
   i=4;
   for(i;i>=0;i--)
   {
       printf("%d",n>>i&1);
   }

    return 0;
}
