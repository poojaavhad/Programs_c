/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#define N 5
int queue [N];
int front=-1;
int rear=-1;
void enqueue(int);
int dequeue();

int main()
{
    int d,choice;
    while(1)
    {
        printf("enter the choice:=");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:scanf("%d",&d);
            enqueue(d);
            break;
            case 2:printf("%d",dequeue());
            break;
        }
    }
}
void enqueue(int d)
{
    if(rear<N-1)
    {
        printf("overflow the queue");
    }
    else if(rear=front==-1)
    {
        printf("queue is empty");
    }
    else
    {
    rear=front=0;
    ++rear;
    queue[rear]=d;
    }
}
int dequeue()
{
    if(rear=front==-1)
    {
        printf("queue is empty");
    }
    else if(rear==front)
    {
        rear=front=-1;
    
    }
    else
    front++;
    return front;
}    
