/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<string.h>

int main()
{
    char a[20];
    
   printf("enter the string\n");
   gets(a);
    char i,j,ch;
    int count=0,Len;
    printf("enter the char\n");
    scanf("%c",&ch);
  Len=strlen(a);
    printf("Len=%d",Len);
    for(i=0;i<Len;i++)
    {
    if(ch==a[i]&&count<2)
    {
    for(j=i;j<Len;j++)
    a[j]=a[j+1];
    
    count++;
    i--;
    Len--;
    }
    
    }
    printf("%s",a);
    return 0;
}