/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
class calculator
{
    int a;
    int b;
    int res;
    public:
    void get_value()
    {
        cin>>a;
        cin>>b;
        res=0;
    }
    void add()
    {
        res=a+b;
        cout<<res<<endl;
    }
    void sub()
    {
        res=a-b;
        cout<<res<<endl;
    }
    void mul()
    {
        res=a*b;
        cout<<res<<endl;
    }
    void division()
    {
        res=a/b;
        cout<<res<<endl;
    }
    //void display()
    //{
        //cout<<res<<endl;
    //}
};

int main()
{
    calculator obj;
    int ch;
    while(1)
    {
        cout<<"enter the option"<<endl;
        cin>>ch;
        switch(ch)
        {
            case 1:obj.get_value();
            break;
            case 2:obj.add();
            break;
            case 3:obj.sub();
            break;
            case 4:obj.mul();
            break;
            case 5:obj.division();
            break;
            case 6:exit(0);
            break;
        }
    }

    return 0;
}