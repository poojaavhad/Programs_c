/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
struct A
{
    int roll;
    char name[20];
    struct A * link;
};
struct A *add_last(struct A*);
void display(struct A*);
struct A * del_first(struct A *);
struct A * del_last(struct A *);

int main()
{
    struct A* head=NULL;
    while(1)
    {
      printf("1.add_last 2.display 3.delet first");  
    
    int choice;
    printf("enter the choice=\n");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:head=add_last(head);
        break;
        case 2:display(head);
        break;
        case 3:head=del_first(head);
        break;
        case 4:head=del_last(head);
        break;
        case 5:exit(0);
        break;
    }
    }
}
struct A* add_last(struct A *ptr)
{
    struct A* newnode=NULL;
    struct A* temp=NULL;
    newnode=calloc(1,sizeof(struct A));
    if(newnode==NULL)
    {
        printf("memory is not alloted");
    }
    else
    {
    printf("enter the element:\n");
    printf("enter the roll no=\n");
    scanf("%d",&newnode->roll);
    printf("enter the name=\n");
    scanf("%s",newnode->name);
    }
    if(ptr==NULL)
    {
        ptr=newnode;
    }
    
    else
    {
        temp=ptr;
    while(temp->link!=NULL)
    {
    temp=temp->link;
    }
    temp->link=newnode;
}

return ptr;
}
void display(struct A *ptr)
{
	if(ptr==NULL)
	{
		printf("List is empty\n");
	}
	else
	{
		while(ptr)
		{
			printf("%d %s\n",ptr->roll,ptr->name);
			ptr=ptr->link;
		}
	}
}
struct A * del_first(struct A *ptr)
{
    struct A * temp=NULL;
    if(ptr == NULL)
    {
        printf("list is empty");
    }
    else if(ptr!=0)
    {
   temp = ptr;
   ptr=ptr->link;
   free(temp);
   temp==NULL;
    }
    else
    printf("list is empty");
    return ptr;
}
struct A * del_last(struct A * ptr)
{
    struct A* temp=NULL;
    struct A* prev=NULL;
    if(ptr==NULL)
	{
		printf("List is empty\n");
	}
	else
	{
		temp=ptr;
		while(temp->link!=NULL)
		{
			prev=temp;
			temp=temp->link;
		}
		if(prev)
			prev->link=NULL;// making last before node as last node
		else
			// list has become empty
		//ptr=NULL;
		free(temp);
		temp=NULL;
	}
	return ptr;
}
