/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
 
int main()
{
    unsigned cn_year,cn_month,cn_date,bt_year,bt_month,bt_date,year,date,month;
    printf("enter the current year=");
    scanf("%d",&cn_year);
    printf("enter the current month=");
    scanf("%d",&cn_month);
    printf("enter the current date=");
    scanf("%d",&bt_date);
    printf("enter the birth year=");
    scanf("%d",&bt_year);
    printf("enter the birth month=");
    scanf("%d",&bt_month);
    printf("enter the birth date=");
    scanf("%d",&cn_date);
    //scanf("%d %d %d",&bt_year,&bt_month,&bt_date);
    year=cn_year-bt_year;
    
    month=cn_month-bt_month;
     if(-month)
     month=-(month);
     else 
     month=month;
     
    
    date=cn_date-bt_date;
    if(-date)
     date=-(date);
     else 
     date=date;
    printf("year=%d/ month=%d/ days=%d",year,month,date);
    
    return 0;
}