/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>


int main ()
{
  int i, j,k;
  for (i = 1; i <= 7; i++)
    {
        if(i<=4)
        {
      for (j = 1; j <= i; j++)
    
        printf ("1");
              printf ("\n");
    }          
      else 
      {
         for (j = i; j <= 7; j++)
	       printf ("1");
              printf ("\n");
              
              
    }
    }


  return 0;
}
