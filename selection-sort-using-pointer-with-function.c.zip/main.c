/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int* sort(int *,int);

int main()
{
    int a[5];
    int i,n;
    int *w;
    n=sizeof a/sizeof a[0];
    printf("enter the array");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    for(i=0;i<n;i++)
    printf("%d",a[i]);
    w=sort(&a[0],n);
    for(i=0;i<n;i++)
    //printf("%d",w[i]);
    return 0;
}
    int* sort(int *p,int n)
    {
        int i,j,temp=0;;
        for(i=0;i<n;i++)
        {
            for(j=i+1;j<n;j++)
            {
                if(*(p+i)>*(p+j))
                {
                   temp=*(p+i);
                   *(p+i)=*(p+j);
                   *(p+j)=temp;
                }
            }
            
        }
        for(i=0;i<n;i++)
        printf("\n%d",*p++);
        return p;
    }
    

    
