/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a[5];
    int i,count=0,j;
    printf("enter the element in array\n");
    for(i=0;i<5;i++)
    scanf("%d",&a[i]);
    //int i,count=0,j;
    for(i=0;i<5;i++)
    {
        count=0;
        if(a[i]%2==0)
        {
            
            printf("even\n");
            
        }
        
        
        
        else if(a[i]%2!=0)
        {
            for(j=1;j<=a[i];j++)
            {
               //count=0;
            if(a[i]%j==0)
            count++;
            
            }
            //printf("%d",count);
            if(count==2)
            printf("prime\n");
            
            
        }
        else if (a[i]%2!=0)
        printf("odd");
            
            
        }

    

    return 0;
}
