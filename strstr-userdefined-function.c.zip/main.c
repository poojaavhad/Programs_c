/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
char* strstr(const char*,const char*);

int main()
{
    char a[10],b[10];
    scanf("%s",a);
    scanf("%s",b);
    char* p;
    p=strstr(a,b);
    if(p==0)
    printf("substring not available");
    else
    printf("substring available at %u",p);
    
    return 0;
}
char* strstr(const char *p,const char *q)
{
    int i,j;
    for(i=0;p[i];i++)
    {
        if(p[i]==q[0])
        {
       for(j=1;q[j];j++)
        {
            if(q[j]!=p[i+j])
            break;
        }
        if(q[j]=='\0')
        return (p+i);
        }
        
    }
    return 0;
}