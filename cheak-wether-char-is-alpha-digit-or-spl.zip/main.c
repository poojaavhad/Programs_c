/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char a[20];
    int count=0,count1=0;
    printf("enter the string\n");
    scanf("%s",a);
    for(int i=0;a[i];i++)
    {
       if(a[i]>=65 && a[i]<=91) 
       printf("%c is a alphabet\n",a[i]);
       else if(a[i]>=97 && a[i]<=122 )
       printf("%c is a alphabet\n",a[i]);
        else if(a[i]>=48 && a[i]<=57 )
         printf("%c is a digit\n",a[i]);
       else
       printf("%c is special character",a[i]);
       
    }
   
    return 0;
}

