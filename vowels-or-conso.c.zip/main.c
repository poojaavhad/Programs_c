/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    char ch;
    printf("enter the char ch=");
    scanf("%c",&ch);
    if(ch=='A'||ch=='a')
    printf("vowel");
    else if(ch=='I'||ch=='i')
    printf("vowel");
    else if(ch=='O'||ch=='o')
    printf("vowel");
    else if(ch=='E'||ch=='e')
    printf("vowel");
    else if(ch=='U'||ch=='u')
    printf("vowel");
    else
    printf("consonant");
    

    return 0;
}
