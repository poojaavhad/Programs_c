/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
   //int main()
//{
    int f1=0,f2=1,f3,i=3,len;
    printf("enter length of the  fibonacci series:");
    scanf("%d",&len);
    if(len==f1)
    printf(" ");
    else if("len==f2")
    printf("%d",f2);
    else
    {
    printf("%d\t%d",f1,f2);
    
    
    while(i<=len)           // checks the condition
    {
        f3=f1+f2;               // performs add operation on previous two  values
        printf("\t%d",f3);      // It prints from third value to given length
        f1=f2;
        f2=f3;
        i=i+1;                  // incrementing the i value by 1
    }
    }
    return 0;
}
