/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int n,count=0,r;
    printf("enter the number-");
    scanf("%d",&n);
    do{
        if(n==0)
        count++;
        else{
        r=n%10;
        count++;
        n=n/10;
        }
        
    }
    while(n>0);
    printf("%d",count);
    
    

    return 0;
}
