/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    char a[20];
    int count=0,count1=0;
    scanf("%s",a);
    for(int i=0;a[i];i++)
    {
       if(a[i]>=65 && a[i]<=90 || a[i]>=97 && a[i]<=122 || a[i]>=48 && a[i]<=57 ) 
       count++;
       else
       count1++;
    }
    printf("punctuation=%d\n",count1);
   // printf("%d",count);
    return 0;
}
