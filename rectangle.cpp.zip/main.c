/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class rectangle
{
    int l;
    int b;
    int area;
    int perimeter;
    
    
public:
void get_data_area()
    {
       cout<<"enter the data"<<endl;
       cout<<"enter the l"<<endl;
       cin>>l;
       cout<<"enter the b"<<endl;
       cin>>b;
    }
void area_cal()
    {
       area=l*b; 
    }  
void perimeter_cal()
{
    perimeter=2*(l+b);
}
void display()
{
    cout<<"area="<<area<<endl;
    cout<<"perimeter="<<perimeter<<endl;
}
       
    
};
int main()
{
    rectangle obj;
    //int a[3];
    
        obj.get_data_area();
        obj.area_cal();
        obj.perimeter_cal();
        obj.display();
    

    return 0;
}