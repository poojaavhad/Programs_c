/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
//palindrome(int *);
//#include<>
int main()
{ int c1=0,c2=0,c3=0,c4=0;
    char *p="poai  jv12";
    char ch='p';
    while(*p)
    {
    if(*p>='0'&&*p<='9')
    {
    c1++;
    p++;
    }
    else if(*p=='a'||*p=='i'||*p=='0'||*p=='e'||*p=='u')
    {
    c2++;
    p++;
    }
   else if(*p==' ')
   {
    c3++;
    p++;
   }
    else 
    {
    c4++;
    p++;
    }
    
    }
    printf("digit=%d",c1);
    printf("vowel=%d",c2);
    printf("conso=%d",c4);
    printf("white%d",c3);
    
    return 0;
}