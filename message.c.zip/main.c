/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

// Online C compiler to run C program online
#include <stdio.h>
 //void set(int *);
int main() {
    // Write C code h
    signed int p=-60;
    
    unsigned char temp=p>>10;
    //printf("%d",temp);
    
    for(int i=7;i>=0;i--)
    printf("%d",temp>>i&1);
    printf("\n");
    
    unsigned char temp1=p>>2;
     for(int i=7;i>=0;i--)
    printf("%d",temp1>>i&1);
    printf("\n");
    
    unsigned char temp2=p<<6;
     for(int i=7;i>=0;i--)
    printf("%d",temp2>>i&1);
    
    unsigned char a=0x02;
    unsigned char temp3;
    
    
   
    

    return 0;
}
    
    
  

