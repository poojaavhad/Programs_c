/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
char * strcat(char *,const char*,int);

int main()
{
   char d[20],s[10];
   char *p;
   int i,n;
   printf("enter the souce string=");
   scanf("%s",s);
   printf("enter the destination string=");
   scanf("%s",d);
   printf("enter the limit");
   scanf("%d",&n);
   p=strcat(d,s,n);
   printf("%s",p);
    return 0;
}
char * strcat(char *d,const char *s,int n)
{
    int i,l;
    for(i=0;d[i];i++);
    printf("%d\n",i);
    printf("%d",n);
    for(l=0;s[l];l++)
    {
        if(n&&s[l])
        {
        d[i]=s[l];
        i++;
        n--;
        }
    }
    d[i]='\0';
    return d;
    
}
