/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,temp,count=0,i;                 //initilization of varr n,temp,count
    printf("enter the number n=\n");   // take number n= from user at run time
    scanf("%d",&n);                   //provide address to varr n
    temp=n;                          // copy data of n to temp
    for(i=1;i<=n;i++)               // check the condition
    {
     if(n%i==0)
     count++;
    }
    if(count==2)
    printf("prime number");
    else
    printf("not prime");

    return 0;
}
