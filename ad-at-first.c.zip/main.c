/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<stdlib.h>
struct student
{
    int roll;
    char a[20];
    struct student *link;
};
struct student * add_first(struct student *);
void display(struct student *);

int main()
{
    struct student head *=NULL;
    int choice;
    printf("enter the choice");
    scanf("%d",&choice)
    while(1)
    {
        switch(choice)
        {
            printf("1:add_last 2:display 3:exit");
            case 1:head=add_last(head);
            break;
            case 2:display(head);
            break'
            case 3:exit(0)
        }
    }

    return 0;
}
struct student * add_first(struct student * ptr);
{
    struct student *new=NULL;
    new=(char *)calloc(1,sizeof(struct studen));
    if(new==NULL)
    {
        printf("memory not allowed");
    }
    else if(new!=null)
    {
        printf("enter the element:");
        printf("enter the roll no");
        scanf("%d",&new->roll);
        printf("enter the name");
        scanf("%s"new->name);
        
    }
    else
    {
        if(ptr==NULL)
        ptr=new;
    }
    return ptr;
}
void display(struct student * ptr)
{
    if(ptr==NULL)
    {
        printf("list not created");
        
    }
    else if(ptr->link==NULL)
    {
    printf("%d",ptr->roll);
    printf("%s",ptr->name);
    }
    
}
    
    
