/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int i,j,k,l;
for(i=-4;i<=4;i++)
{
    if(i<0)
    l=-i;
    else
    l=i;
    for(j=1;j<=l;j++)
    printf(" ");
    for(k=4;k>=l;k--)
    printf("* ");
    printf("\n");
}
return 0;

    
}

    
