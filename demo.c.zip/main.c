/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int * my_strchr(char *a,char b);
int main()
{
    char *ret;
    char a[10];
    char b;
     printf("enter the char\n");
     scanf("%s",a);
     printf("enter the char\n");
     scanf("%c ",&b);
     printf("%u\n",a);
  ret=my_strchr(a,b);
  printf("%u",ret);
    return 0;
}
int * my_strchr(char *a,char b)
{
    int i;
    for(i=0;a[i];i++)
    
        if(a[i]==b)
        break;
    
    printf("i=%d\n",i);
    return a;
}