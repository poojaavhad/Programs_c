/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
int a,b,c;
printf("enter the number a,b,c...");
scanf("%d %d %d",&a, &b, &c);
if(a>b)
{
if(a>c)
//{
printf("a is the greastest number");
else
printf("c is the greastest number");
}
else
{
if(b>c)
//{
printf("b is the greatest number");
else
printf("c is the greastest number");
//}
//}
}


    return 0;
}
