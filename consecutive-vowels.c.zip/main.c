/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
int i,c=0,j,count=0;
    char a[10][10]={"pooja","reetesh","era","aiopu","koaml"};
    for(i=0;i<10;i++)
    {    c=0;
        for(j=0;j<10;j++)
        { 
            if(a[i][j]=='a'||a[i][j]=='i'||a[i][j]=='e'||a[i][j]=='o'||a[i][j]=='u')
            {
                
            if(a[i][j+1]=='a'||a[i][j+1]=='i'||a[i][j+1]=='e'||a[i][j+1]=='o'||a[i][j+1]=='u') 
            
                c++;
            }
            //printf("%d",c);
            //printf("%s\n",a[i]);
        }
        if(c==1||c==2)
        {
            printf("%s\n",a[i]);
            count++;
        }
        //printf("count=%d",count);
            
    }
    printf("count=%d",count);
    
    return 0;
}
