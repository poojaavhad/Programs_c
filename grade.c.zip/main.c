/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n;
    printf("enter the numner n");
    scanf("%d",&n);
    if(0<n && n <=20)
    printf("garde is E2");
     else if(21<n && n<=32)
    printf("grade is E1");
    else if(33<n && n<=40)
    printf("grade is D");
    else if(41<n && n<=50)
    printf("grade is C2");
    else if(51<n && n<=60)
    printf("grade is C1");
    else if(61<n && n<=70)
    printf("grade is B2");
    else if(61<n && n<=70)
    printf("grade is B2");
    else if(71<n && n<=80)
    printf("grade is B1");
    else if(81<n && n<=90)
    printf("grade is A2");
    else if(91<n && n<=100)
    printf("grade is A1");








    return 0;
}
