/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#define size 5
void push(int *);
void pop(int *);
void peak(int *);
void display(int *);
int top=-1;
int main()
{  //static int top=-1;
    int stk[size];
    int op;
    while(1)
    {
        printf("1:push 2:pop 3:peak 4:display 5:exit\n");
        printf("enter the oprion\n");
        scanf("%d",&op);
        switch(op)
        {
            case 1:push(stk);
            break;
            case 2:pop(stk);
            break;
            case 3:peak(stk);
            break;
            case 4:display(stk);
            break;
            case 5:exit(0);
            break;
        }
    }
  

    return 0;
}
void push(int * stk)
{
    int data;
   // printf("enter the data\n");
    //scanf("%d",&data);
    if(top>=size-1)
    {
        printf("stack is overflow");
    }
    else
    {
        printf("enter the data\n");
    scanf("%d",&data);
        stk[++top]=data;
    
    }
}
void pop(int * stk)
{
    int temp;
    if(top<=-1)
    {
    printf("stack is underflow\n");
    return 0;
    }
    else
    {
    temp=stk[top--];
    printf("pop=%d",temp);
    }
}
void peak(int * stk)
{
   printf("%d",top); 
}
void display(int *stk)
{
    int i;
    for(i=0;i<=top;i++)
    printf("%d",stk[i]);
}
    
    
    
